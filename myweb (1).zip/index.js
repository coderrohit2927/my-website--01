
function mouseoutimg() {
    document.querySelector(".col-lg-4").style.transition = "0.5s"
    document.querySelector(".col-lg-4").nextElementSibling.style.transition = "0.5s"
    document.querySelector("#flex>div>img").style.transition = "0.5s"
    document.querySelector(".row3").lastElementChild.style.transition = "0.5s"
    document.querySelector(".img1>img").style.transition = "1s"
    document.querySelectorAll(".mans")[0].style.transition = "0.5s"
    document.querySelectorAll(".mans")[1].style.transition = "0.5s"
}
 